package za.co.kmcapture

import android.content.*
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.*
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.json.*
import java.io.File
import java.util.zip.*

data class Slip(val date: String, val station: String, val litres: String, val total: String, val odo: String)

fun parse(t: String): Slip {
    var date = ""
    Regex("""(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})""").find(t)?.let {
        date = "%s-%02d-%02d".format(it.groupValues[1], it.groupValues[2].toInt(), it.groupValues[3].toInt())
    }
    if (date.isEmpty()) Regex("""(\d{1,2})[-/.](\d{1,2})[-/.](\d{2,4})""").find(t)?.let {
        val y = it.groupValues[3].let { s -> if (s.length == 2) "20$s" else s }
        date = "%s-%02d-%02d".format(y, it.groupValues[2].toInt(), it.groupValues[1].toInt())
    }
    val num = """(\d+[.,]\d{2,3})"""
    val litres = Regex("""$num\s*(?:L|l|ltr|litres?)\b""").find(t)?.groupValues?.get(1)?.replace(',', '.') ?: ""
    val total = Regex("""(?i)(?:total|amount|amt)[^\d\n]{0,12}$num""").find(t)?.groupValues?.get(1)?.replace(',', '.') ?: ""
    val odo = Regex("""(?i)(?:odo\w*|km|mileage)[^\d\n]{0,8}(\d{3,7})""").find(t)?.groupValues?.get(1) ?: ""
    val station = t.lines().firstOrNull { it.isNotBlank() }?.trim() ?: ""
    return Slip(date, station, litres, total, odo)
}

fun load(c: Context): List<Slip> {
    val a = JSONArray(c.getSharedPreferences("km", 0).getString("d", "[]"))
    return List(a.length()) { val o = a.getJSONObject(it); Slip(o.getString("d"), o.getString("s"), o.getString("l"), o.getString("t"), o.getString("o")) }
}

fun save(c: Context, l: List<Slip>) {
    val a = JSONArray()
    l.forEach { a.put(JSONObject().put("d", it.date).put("s", it.station).put("l", it.litres).put("t", it.total).put("o", it.odo)) }
    c.getSharedPreferences("km", 0).edit().putString("d", a.toString()).apply()
}

fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

fun exportXlsx(c: Context, l: List<Slip>): Uri {
    val rows = listOf(listOf("Date", "Station", "Litres", "Total (R)", "Odometer (km)")) +
        l.sortedBy { it.date }.map { listOf(it.date, it.station, it.litres, it.total, it.odo) }
    val sb = StringBuilder("""<?xml version="1.0" encoding="UTF-8"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>""")
    rows.forEachIndexed { r, row ->
        sb.append("<row r=\"${r + 1}\">")
        row.forEachIndexed { i, v ->
            val ref = "${'A' + i}${r + 1}"
            if (r > 0 && i >= 2 && v.toDoubleOrNull() != null) sb.append("<c r=\"$ref\"><v>$v</v></c>")
            else sb.append("<c r=\"$ref\" t=\"inlineStr\"><is><t>${esc(v)}</t></is></c>")
        }
        sb.append("</row>")
    }
    sb.append("</sheetData></worksheet>")
    val ns = "http://schemas.openxmlformats.org/"
    val f = File(c.cacheDir, "Km_Capture.xlsx")
    ZipOutputStream(f.outputStream()).use { z ->
        fun put(n: String, s: String) { z.putNextEntry(ZipEntry(n)); z.write(s.toByteArray()); z.closeEntry() }
        put("[Content_Types].xml", """<Types xmlns="${ns}package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>""")
        put("_rels/.rels", """<Relationships xmlns="${ns}package/2006/relationships"><Relationship Id="rId1" Type="${ns}officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>""")
        put("xl/workbook.xml", """<workbook xmlns="${ns}spreadsheetml/2006/main" xmlns:r="${ns}officeDocument/2006/relationships"><sheets><sheet name="Fuel Slips" sheetId="1" r:id="rId1"/></sheets></workbook>""")
        put("xl/_rels/workbook.xml.rels", """<Relationships xmlns="${ns}package/2006/relationships"><Relationship Id="rId1" Type="${ns}officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>""")
        put("xl/worksheets/sheet1.xml", sb.toString())
    }
    return FileProvider.getUriForFile(c, "${c.packageName}.files", f)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContent { MaterialTheme { App() } }
    }
}

@Composable
fun App() {
    val c = LocalContext.current
    val slips = remember { mutableStateListOf<Slip>().apply { addAll(load(c)) } }
    var draft by remember { mutableStateOf<Slip?>(null) }
    var busy by remember { mutableStateOf(false) }
    var photo by remember { mutableStateOf<Uri?>(null) }

    fun scan(u: Uri) {
        busy = true
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            .process(InputImage.fromFilePath(c, u))
            .addOnSuccessListener { draft = parse(it.text); busy = false }
            .addOnFailureListener { draft = Slip("", "", "", "", ""); busy = false }
    }
    val cam = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok -> if (ok) photo?.let { scan(it) } }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { u -> u?.let { scan(it) } }

    Column(Modifier.fillMaxSize().statusBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Km Capture", style = MaterialTheme.typography.headlineMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = {
                val f = File.createTempFile("slip", ".jpg", c.cacheDir)
                val u = FileProvider.getUriForFile(c, "${c.packageName}.files", f)
                photo = u; cam.launch(u)
            }) { Text("Take photo") }
            Button(onClick = { pick.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }) { Text("Gallery") }
        }
        Button(enabled = slips.isNotEmpty(), onClick = {
            val i = Intent(Intent.ACTION_SEND).apply {
                type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                putExtra(Intent.EXTRA_STREAM, exportXlsx(c, slips))
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            c.startActivity(Intent.createChooser(i, "Export Excel"))
        }) { Text("Export to Excel (by date)") }
        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(slips.sortedBy { it.date }) { s ->
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(12.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("${s.date}  ·  ${s.station}")
                            Text("${s.litres} L  ·  R${s.total}  ·  ${s.odo} km")
                        }
                        TextButton(onClick = { slips.remove(s); save(c, slips) }) { Text("Delete") }
                    }
                }
            }
        }
    }
    draft?.let { d ->
        EditDialog(d, onCancel = { draft = null }) { s ->
            slips.add(s); save(c, slips); draft = null
        }
    }
}

@Composable
fun EditDialog(init: Slip, onCancel: () -> Unit, onSave: (Slip) -> Unit) {
    var date by remember { mutableStateOf(init.date) }
    var st by remember { mutableStateOf(init.station) }
    var l by remember { mutableStateOf(init.litres) }
    var t by remember { mutableStateOf(init.total) }
    var o by remember { mutableStateOf(init.odo) }
    AlertDialog(
        onDismissRequest = onCancel,
        title = { Text("Check slip details") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(date, { date = it }, label = { Text("Date (yyyy-mm-dd)") }, singleLine = true)
                OutlinedTextField(st, { st = it }, label = { Text("Station") }, singleLine = true)
                OutlinedTextField(l, { l = it }, label = { Text("Litres") }, singleLine = true)
                OutlinedTextField(t, { t = it }, label = { Text("Total (R)") }, singleLine = true)
                OutlinedTextField(o, { o = it }, label = { Text("Odometer (km)") }, singleLine = true)
            }
        },
        confirmButton = { TextButton(onClick = { onSave(Slip(date, st, l, t, o)) }) { Text("Save") } },
        dismissButton = { TextButton(onClick = onCancel) { Text("Cancel") } }
    )
}
